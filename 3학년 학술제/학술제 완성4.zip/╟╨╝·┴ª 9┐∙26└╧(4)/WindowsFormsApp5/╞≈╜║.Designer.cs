﻿namespace WindowsFormsApp5
{
    partial class 포스
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(포스));
			this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
			this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
			this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
			this.dataGridView1 = new System.Windows.Forms.DataGridView();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
			this.textBox3 = new System.Windows.Forms.TextBox();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.label19 = new System.Windows.Forms.Label();
			this.textBox18 = new System.Windows.Forms.TextBox();
			this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
			this.groupBox4 = new System.Windows.Forms.GroupBox();
			this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
			this.tableLayoutPanel30 = new System.Windows.Forms.TableLayoutPanel();
			this.button20 = new System.Windows.Forms.Button();
			this.button19 = new System.Windows.Forms.Button();
			this.button18 = new System.Windows.Forms.Button();
			this.button17 = new System.Windows.Forms.Button();
			this.tableLayoutPanel31 = new System.Windows.Forms.TableLayoutPanel();
			this.button21 = new System.Windows.Forms.Button();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
			this.button16 = new System.Windows.Forms.Button();
			this.button15 = new System.Windows.Forms.Button();
			this.button14 = new System.Windows.Forms.Button();
			this.button13 = new System.Windows.Forms.Button();
			this.button12 = new System.Windows.Forms.Button();
			this.button11 = new System.Windows.Forms.Button();
			this.button10 = new System.Windows.Forms.Button();
			this.button9 = new System.Windows.Forms.Button();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
			this.button8 = new System.Windows.Forms.Button();
			this.button7 = new System.Windows.Forms.Button();
			this.button6 = new System.Windows.Forms.Button();
			this.button5 = new System.Windows.Forms.Button();
			this.button4 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
			this.tableLayoutPanel14 = new System.Windows.Forms.TableLayoutPanel();
			this.groupBox6 = new System.Windows.Forms.GroupBox();
			this.tableLayoutPanel15 = new System.Windows.Forms.TableLayoutPanel();
			this.button35 = new System.Windows.Forms.Button();
			this.button34 = new System.Windows.Forms.Button();
			this.button33 = new System.Windows.Forms.Button();
			this.button32 = new System.Windows.Forms.Button();
			this.button31 = new System.Windows.Forms.Button();
			this.button30 = new System.Windows.Forms.Button();
			this.button29 = new System.Windows.Forms.Button();
			this.button28 = new System.Windows.Forms.Button();
			this.button27 = new System.Windows.Forms.Button();
			this.groupBox5 = new System.Windows.Forms.GroupBox();
			this.tableLayoutPanel16 = new System.Windows.Forms.TableLayoutPanel();
			this.label8 = new System.Windows.Forms.Label();
			this.textBox4 = new System.Windows.Forms.TextBox();
			this.textBox5 = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.textBox6 = new System.Windows.Forms.TextBox();
			this.label10 = new System.Windows.Forms.Label();
			this.textBox7 = new System.Windows.Forms.TextBox();
			this.textBox8 = new System.Windows.Forms.TextBox();
			this.tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
			this.tableLayoutPanel13 = new System.Windows.Forms.TableLayoutPanel();
			this.tableLayoutPanel32 = new System.Windows.Forms.TableLayoutPanel();
			this.button23 = new System.Windows.Forms.Button();
			this.tableLayoutPanel33 = new System.Windows.Forms.TableLayoutPanel();
			this.button24 = new System.Windows.Forms.Button();
			this.tableLayoutPanel34 = new System.Windows.Forms.TableLayoutPanel();
			this.button22 = new System.Windows.Forms.Button();
			this.button25 = new System.Windows.Forms.Button();
			this.tableLayoutPanel35 = new System.Windows.Forms.TableLayoutPanel();
			this.button26 = new System.Windows.Forms.Button();
			this.dataGridView2 = new System.Windows.Forms.DataGridView();
			this.tableLayoutPanel42 = new System.Windows.Forms.TableLayoutPanel();
			this.groupBox12 = new System.Windows.Forms.GroupBox();
			this.textBox20 = new System.Windows.Forms.TextBox();
			this.button54 = new System.Windows.Forms.Button();
			this.tabPage3 = new System.Windows.Forms.TabPage();
			this.tableLayoutPanel17 = new System.Windows.Forms.TableLayoutPanel();
			this.tableLayoutPanel18 = new System.Windows.Forms.TableLayoutPanel();
			this.dataGridView3 = new System.Windows.Forms.DataGridView();
			this.tableLayoutPanel19 = new System.Windows.Forms.TableLayoutPanel();
			this.groupBox7 = new System.Windows.Forms.GroupBox();
			this.tableLayoutPanel20 = new System.Windows.Forms.TableLayoutPanel();
			this.label11 = new System.Windows.Forms.Label();
			this.textBox9 = new System.Windows.Forms.TextBox();
			this.button41 = new System.Windows.Forms.Button();
			this.groupBox8 = new System.Windows.Forms.GroupBox();
			this.tableLayoutPanel21 = new System.Windows.Forms.TableLayoutPanel();
			this.label12 = new System.Windows.Forms.Label();
			this.label13 = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.label15 = new System.Windows.Forms.Label();
			this.tableLayoutPanel36 = new System.Windows.Forms.TableLayoutPanel();
			this.textBox10 = new System.Windows.Forms.TextBox();
			this.groupBox11 = new System.Windows.Forms.GroupBox();
			this.tableLayoutPanel40 = new System.Windows.Forms.TableLayoutPanel();
			this.radioButton1 = new System.Windows.Forms.RadioButton();
			this.radioButton2 = new System.Windows.Forms.RadioButton();
			this.tableLayoutPanel37 = new System.Windows.Forms.TableLayoutPanel();
			this.textBox11 = new System.Windows.Forms.TextBox();
			this.tableLayoutPanel38 = new System.Windows.Forms.TableLayoutPanel();
			this.textBox12 = new System.Windows.Forms.TextBox();
			this.tableLayoutPanel39 = new System.Windows.Forms.TableLayoutPanel();
			this.textBox13 = new System.Windows.Forms.TextBox();
			this.tableLayoutPanel22 = new System.Windows.Forms.TableLayoutPanel();
			this.button42 = new System.Windows.Forms.Button();
			this.button43 = new System.Windows.Forms.Button();
			this.tableLayoutPanel23 = new System.Windows.Forms.TableLayoutPanel();
			this.button47 = new System.Windows.Forms.Button();
			this.button46 = new System.Windows.Forms.Button();
			this.button45 = new System.Windows.Forms.Button();
			this.button44 = new System.Windows.Forms.Button();
			this.tabPage4 = new System.Windows.Forms.TabPage();
			this.tableLayoutPanel24 = new System.Windows.Forms.TableLayoutPanel();
			this.tableLayoutPanel25 = new System.Windows.Forms.TableLayoutPanel();
			this.groupBox9 = new System.Windows.Forms.GroupBox();
			this.tableLayoutPanel26 = new System.Windows.Forms.TableLayoutPanel();
			this.label16 = new System.Windows.Forms.Label();
			this.label17 = new System.Windows.Forms.Label();
			this.label18 = new System.Windows.Forms.Label();
			this.textBox14 = new System.Windows.Forms.TextBox();
			this.textBox15 = new System.Windows.Forms.TextBox();
			this.textBox16 = new System.Windows.Forms.TextBox();
			this.label20 = new System.Windows.Forms.Label();
			this.textBox17 = new System.Windows.Forms.TextBox();
			this.groupBox10 = new System.Windows.Forms.GroupBox();
			this.tableLayoutPanel29 = new System.Windows.Forms.TableLayoutPanel();
			this.tableLayoutPanel27 = new System.Windows.Forms.TableLayoutPanel();
			this.button36 = new System.Windows.Forms.Button();
			this.button37 = new System.Windows.Forms.Button();
			this.button38 = new System.Windows.Forms.Button();
			this.button39 = new System.Windows.Forms.Button();
			this.button40 = new System.Windows.Forms.Button();
			this.button48 = new System.Windows.Forms.Button();
			this.button49 = new System.Windows.Forms.Button();
			this.button50 = new System.Windows.Forms.Button();
			this.button51 = new System.Windows.Forms.Button();
			this.tableLayoutPanel41 = new System.Windows.Forms.TableLayoutPanel();
			this.button52 = new System.Windows.Forms.Button();
			this.button53 = new System.Windows.Forms.Button();
			this.tableLayoutPanel28 = new System.Windows.Forms.TableLayoutPanel();
			this.dataGridView4 = new System.Windows.Forms.DataGridView();
			this.textBox19 = new System.Windows.Forms.TextBox();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			this.statusStrip1 = new System.Windows.Forms.StatusStrip();
			this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
			this.toolStripSplitButton1 = new System.Windows.Forms.ToolStripSplitButton();
			this.timer2 = new System.Windows.Forms.Timer(this.components);
			this.printDocument1 = new System.Drawing.Printing.PrintDocument();
			this.printDialog1 = new System.Windows.Forms.PrintDialog();
			this.tableLayoutPanel1.SuspendLayout();
			this.tabControl1.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.tableLayoutPanel2.SuspendLayout();
			this.tableLayoutPanel4.SuspendLayout();
			this.tableLayoutPanel5.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
			this.groupBox1.SuspendLayout();
			this.tableLayoutPanel6.SuspendLayout();
			this.tableLayoutPanel7.SuspendLayout();
			this.groupBox4.SuspendLayout();
			this.tableLayoutPanel8.SuspendLayout();
			this.tableLayoutPanel30.SuspendLayout();
			this.tableLayoutPanel31.SuspendLayout();
			this.groupBox3.SuspendLayout();
			this.tableLayoutPanel9.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.tableLayoutPanel10.SuspendLayout();
			this.tableLayoutPanel3.SuspendLayout();
			this.tabPage2.SuspendLayout();
			this.tableLayoutPanel11.SuspendLayout();
			this.tableLayoutPanel14.SuspendLayout();
			this.groupBox6.SuspendLayout();
			this.tableLayoutPanel15.SuspendLayout();
			this.groupBox5.SuspendLayout();
			this.tableLayoutPanel16.SuspendLayout();
			this.tableLayoutPanel12.SuspendLayout();
			this.tableLayoutPanel13.SuspendLayout();
			this.tableLayoutPanel32.SuspendLayout();
			this.tableLayoutPanel33.SuspendLayout();
			this.tableLayoutPanel34.SuspendLayout();
			this.tableLayoutPanel35.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
			this.tableLayoutPanel42.SuspendLayout();
			this.groupBox12.SuspendLayout();
			this.tabPage3.SuspendLayout();
			this.tableLayoutPanel17.SuspendLayout();
			this.tableLayoutPanel18.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
			this.tableLayoutPanel19.SuspendLayout();
			this.groupBox7.SuspendLayout();
			this.tableLayoutPanel20.SuspendLayout();
			this.groupBox8.SuspendLayout();
			this.tableLayoutPanel21.SuspendLayout();
			this.tableLayoutPanel36.SuspendLayout();
			this.groupBox11.SuspendLayout();
			this.tableLayoutPanel40.SuspendLayout();
			this.tableLayoutPanel37.SuspendLayout();
			this.tableLayoutPanel38.SuspendLayout();
			this.tableLayoutPanel39.SuspendLayout();
			this.tableLayoutPanel22.SuspendLayout();
			this.tableLayoutPanel23.SuspendLayout();
			this.tabPage4.SuspendLayout();
			this.tableLayoutPanel24.SuspendLayout();
			this.tableLayoutPanel25.SuspendLayout();
			this.groupBox9.SuspendLayout();
			this.tableLayoutPanel26.SuspendLayout();
			this.groupBox10.SuspendLayout();
			this.tableLayoutPanel29.SuspendLayout();
			this.tableLayoutPanel27.SuspendLayout();
			this.tableLayoutPanel41.SuspendLayout();
			this.tableLayoutPanel28.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
			this.statusStrip1.SuspendLayout();
			this.SuspendLayout();
			// 
			// tableLayoutPanel1
			// 
			this.tableLayoutPanel1.ColumnCount = 1;
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel1.Controls.Add(this.tabControl1, 0, 0);
			this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
			this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel1.Name = "tableLayoutPanel1";
			this.tableLayoutPanel1.RowCount = 1;
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel1.Size = new System.Drawing.Size(1314, 697);
			this.tableLayoutPanel1.TabIndex = 0;
			// 
			// tabControl1
			// 
			this.tabControl1.Controls.Add(this.tabPage1);
			this.tabControl1.Controls.Add(this.tabPage2);
			this.tabControl1.Controls.Add(this.tabPage3);
			this.tabControl1.Controls.Add(this.tabPage4);
			this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tabControl1.Location = new System.Drawing.Point(3, 4);
			this.tabControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(1308, 689);
			this.tabControl1.TabIndex = 0;
			// 
			// tabPage1
			// 
			this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(228)))), ((int)(((byte)(242)))));
			this.tabPage1.Controls.Add(this.tableLayoutPanel2);
			this.tabPage1.Location = new System.Drawing.Point(4, 25);
			this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tabPage1.Size = new System.Drawing.Size(1300, 660);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "주문";
			// 
			// tableLayoutPanel2
			// 
			this.tableLayoutPanel2.ColumnCount = 1;
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel4, 0, 1);
			this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 0, 0);
			this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 4);
			this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel2.Name = "tableLayoutPanel2";
			this.tableLayoutPanel2.RowCount = 2;
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.149502F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 94.8505F));
			this.tableLayoutPanel2.Size = new System.Drawing.Size(1294, 652);
			this.tableLayoutPanel2.TabIndex = 0;
			// 
			// tableLayoutPanel4
			// 
			this.tableLayoutPanel4.ColumnCount = 2;
			this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel5, 0, 0);
			this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel7, 1, 0);
			this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 37);
			this.tableLayoutPanel4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel4.Name = "tableLayoutPanel4";
			this.tableLayoutPanel4.RowCount = 1;
			this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 610F));
			this.tableLayoutPanel4.Size = new System.Drawing.Size(1288, 611);
			this.tableLayoutPanel4.TabIndex = 1;
			// 
			// tableLayoutPanel5
			// 
			this.tableLayoutPanel5.ColumnCount = 1;
			this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 23F));
			this.tableLayoutPanel5.Controls.Add(this.dataGridView1, 0, 0);
			this.tableLayoutPanel5.Controls.Add(this.groupBox1, 0, 1);
			this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 4);
			this.tableLayoutPanel5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel5.Name = "tableLayoutPanel5";
			this.tableLayoutPanel5.RowCount = 2;
			this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 66.54611F));
			this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.45389F));
			this.tableLayoutPanel5.Size = new System.Drawing.Size(638, 603);
			this.tableLayoutPanel5.TabIndex = 0;
			// 
			// dataGridView1
			// 
			this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
			this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dataGridView1.Location = new System.Drawing.Point(3, 4);
			this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.dataGridView1.Name = "dataGridView1";
			this.dataGridView1.RowTemplate.Height = 23;
			this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.dataGridView1.Size = new System.Drawing.Size(632, 393);
			this.dataGridView1.TabIndex = 0;
			this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
			this.dataGridView1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick_1);
			this.dataGridView1.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dataGridView1_RowPostPaint);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.tableLayoutPanel6);
			this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox1.Location = new System.Drawing.Point(3, 405);
			this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.groupBox1.Size = new System.Drawing.Size(632, 194);
			this.groupBox1.TabIndex = 1;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "금액";
			// 
			// tableLayoutPanel6
			// 
			this.tableLayoutPanel6.ColumnCount = 2;
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel6.Controls.Add(this.textBox3, 1, 2);
			this.tableLayoutPanel6.Controls.Add(this.textBox2, 1, 1);
			this.tableLayoutPanel6.Controls.Add(this.label5, 0, 0);
			this.tableLayoutPanel6.Controls.Add(this.label6, 0, 1);
			this.tableLayoutPanel6.Controls.Add(this.label7, 0, 2);
			this.tableLayoutPanel6.Controls.Add(this.textBox1, 1, 0);
			this.tableLayoutPanel6.Controls.Add(this.label19, 0, 3);
			this.tableLayoutPanel6.Controls.Add(this.textBox18, 1, 3);
			this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 22);
			this.tableLayoutPanel6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel6.Name = "tableLayoutPanel6";
			this.tableLayoutPanel6.RowCount = 4;
			this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.00062F));
			this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.00062F));
			this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.00062F));
			this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 24.99813F));
			this.tableLayoutPanel6.Size = new System.Drawing.Size(626, 168);
			this.tableLayoutPanel6.TabIndex = 0;
			// 
			// textBox3
			// 
			this.textBox3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBox3.Font = new System.Drawing.Font("굴림", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.textBox3.Location = new System.Drawing.Point(316, 88);
			this.textBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.textBox3.Multiline = true;
			this.textBox3.Name = "textBox3";
			this.textBox3.Size = new System.Drawing.Size(307, 34);
			this.textBox3.TabIndex = 7;
			this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// textBox2
			// 
			this.textBox2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBox2.Font = new System.Drawing.Font("굴림", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.textBox2.Location = new System.Drawing.Point(316, 46);
			this.textBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.textBox2.Multiline = true;
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new System.Drawing.Size(307, 34);
			this.textBox2.TabIndex = 6;
			this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
			this.label5.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.label5.Location = new System.Drawing.Point(3, 0);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(307, 42);
			this.label5.TabIndex = 0;
			this.label5.Text = "총금액";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
			this.label6.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.label6.Location = new System.Drawing.Point(3, 42);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(307, 42);
			this.label6.TabIndex = 1;
			this.label6.Text = "할인금액";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
			this.label7.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.label7.Location = new System.Drawing.Point(3, 84);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(307, 42);
			this.label7.TabIndex = 2;
			this.label7.Text = "할인후금액";
			this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// textBox1
			// 
			this.textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBox1.Font = new System.Drawing.Font("굴림", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.textBox1.Location = new System.Drawing.Point(316, 4);
			this.textBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.textBox1.Multiline = true;
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(307, 34);
			this.textBox1.TabIndex = 5;
			this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// label19
			// 
			this.label19.AutoSize = true;
			this.label19.Dock = System.Windows.Forms.DockStyle.Fill;
			this.label19.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.label19.Location = new System.Drawing.Point(3, 126);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(307, 42);
			this.label19.TabIndex = 8;
			this.label19.Text = "배달주소";
			this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// textBox18
			// 
			this.textBox18.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBox18.Font = new System.Drawing.Font("굴림", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.textBox18.Location = new System.Drawing.Point(316, 130);
			this.textBox18.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.textBox18.Multiline = true;
			this.textBox18.Name = "textBox18";
			this.textBox18.Size = new System.Drawing.Size(307, 34);
			this.textBox18.TabIndex = 9;
			// 
			// tableLayoutPanel7
			// 
			this.tableLayoutPanel7.ColumnCount = 1;
			this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel7.Controls.Add(this.groupBox4, 0, 2);
			this.tableLayoutPanel7.Controls.Add(this.groupBox3, 0, 1);
			this.tableLayoutPanel7.Controls.Add(this.groupBox2, 0, 0);
			this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel7.Location = new System.Drawing.Point(647, 4);
			this.tableLayoutPanel7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel7.Name = "tableLayoutPanel7";
			this.tableLayoutPanel7.RowCount = 3;
			this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
			this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
			this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
			this.tableLayoutPanel7.Size = new System.Drawing.Size(638, 603);
			this.tableLayoutPanel7.TabIndex = 1;
			// 
			// groupBox4
			// 
			this.groupBox4.Controls.Add(this.tableLayoutPanel8);
			this.groupBox4.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox4.Location = new System.Drawing.Point(3, 406);
			this.groupBox4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.groupBox4.Name = "groupBox4";
			this.groupBox4.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.groupBox4.Size = new System.Drawing.Size(632, 193);
			this.groupBox4.TabIndex = 1;
			this.groupBox4.TabStop = false;
			this.groupBox4.Text = "기타";
			// 
			// tableLayoutPanel8
			// 
			this.tableLayoutPanel8.ColumnCount = 2;
			this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 66.66666F));
			this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
			this.tableLayoutPanel8.Controls.Add(this.tableLayoutPanel30, 0, 0);
			this.tableLayoutPanel8.Controls.Add(this.tableLayoutPanel31, 1, 0);
			this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel8.Location = new System.Drawing.Point(3, 22);
			this.tableLayoutPanel8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel8.Name = "tableLayoutPanel8";
			this.tableLayoutPanel8.RowCount = 1;
			this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel8.Size = new System.Drawing.Size(626, 167);
			this.tableLayoutPanel8.TabIndex = 0;
			// 
			// tableLayoutPanel30
			// 
			this.tableLayoutPanel30.ColumnCount = 2;
			this.tableLayoutPanel30.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel30.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel30.Controls.Add(this.button20, 1, 1);
			this.tableLayoutPanel30.Controls.Add(this.button19, 0, 1);
			this.tableLayoutPanel30.Controls.Add(this.button18, 1, 0);
			this.tableLayoutPanel30.Controls.Add(this.button17, 0, 0);
			this.tableLayoutPanel30.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel30.Location = new System.Drawing.Point(3, 2);
			this.tableLayoutPanel30.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.tableLayoutPanel30.Name = "tableLayoutPanel30";
			this.tableLayoutPanel30.RowCount = 2;
			this.tableLayoutPanel30.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel30.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel30.Size = new System.Drawing.Size(411, 163);
			this.tableLayoutPanel30.TabIndex = 0;
			// 
			// button20
			// 
			this.button20.BackColor = System.Drawing.Color.White;
			this.button20.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button20.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button20.Location = new System.Drawing.Point(208, 83);
			this.button20.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.button20.Name = "button20";
			this.button20.Size = new System.Drawing.Size(200, 78);
			this.button20.TabIndex = 3;
			this.button20.Text = "주문메뉴 삭제";
			this.button20.UseVisualStyleBackColor = false;
			this.button20.Click += new System.EventHandler(this.button20_Click);
			// 
			// button19
			// 
			this.button19.BackColor = System.Drawing.Color.White;
			this.button19.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button19.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button19.Location = new System.Drawing.Point(3, 83);
			this.button19.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.button19.Name = "button19";
			this.button19.Size = new System.Drawing.Size(199, 78);
			this.button19.TabIndex = 2;
			this.button19.Text = "배달";
			this.button19.UseVisualStyleBackColor = false;
			this.button19.Click += new System.EventHandler(this.button19_Click);
			// 
			// button18
			// 
			this.button18.BackColor = System.Drawing.Color.White;
			this.button18.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button18.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button18.Location = new System.Drawing.Point(208, 2);
			this.button18.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.button18.Name = "button18";
			this.button18.Size = new System.Drawing.Size(200, 77);
			this.button18.TabIndex = 1;
			this.button18.Text = "테이크아웃";
			this.button18.UseVisualStyleBackColor = false;
			this.button18.Click += new System.EventHandler(this.button18_Click);
			// 
			// button17
			// 
			this.button17.BackColor = System.Drawing.Color.White;
			this.button17.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button17.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button17.Location = new System.Drawing.Point(3, 2);
			this.button17.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.button17.Name = "button17";
			this.button17.Size = new System.Drawing.Size(199, 77);
			this.button17.TabIndex = 0;
			this.button17.Text = "매장식사";
			this.button17.UseVisualStyleBackColor = false;
			this.button17.Click += new System.EventHandler(this.button17_Click);
			// 
			// tableLayoutPanel31
			// 
			this.tableLayoutPanel31.ColumnCount = 1;
			this.tableLayoutPanel31.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel31.Controls.Add(this.button21, 0, 0);
			this.tableLayoutPanel31.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel31.Location = new System.Drawing.Point(420, 2);
			this.tableLayoutPanel31.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.tableLayoutPanel31.Name = "tableLayoutPanel31";
			this.tableLayoutPanel31.RowCount = 1;
			this.tableLayoutPanel31.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel31.Size = new System.Drawing.Size(203, 163);
			this.tableLayoutPanel31.TabIndex = 1;
			// 
			// button21
			// 
			this.button21.BackColor = System.Drawing.Color.White;
			this.button21.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button21.Font = new System.Drawing.Font("굴림", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button21.Location = new System.Drawing.Point(3, 2);
			this.button21.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.button21.Name = "button21";
			this.button21.Size = new System.Drawing.Size(197, 159);
			this.button21.TabIndex = 0;
			this.button21.Text = "계산";
			this.button21.UseVisualStyleBackColor = false;
			this.button21.Click += new System.EventHandler(this.button21_Click);
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.Add(this.tableLayoutPanel9);
			this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox3.Location = new System.Drawing.Point(3, 205);
			this.groupBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.groupBox3.Size = new System.Drawing.Size(632, 193);
			this.groupBox3.TabIndex = 1;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "토핑, 사이드";
			// 
			// tableLayoutPanel9
			// 
			this.tableLayoutPanel9.ColumnCount = 4;
			this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel9.Controls.Add(this.button16, 3, 1);
			this.tableLayoutPanel9.Controls.Add(this.button15, 2, 1);
			this.tableLayoutPanel9.Controls.Add(this.button14, 1, 1);
			this.tableLayoutPanel9.Controls.Add(this.button13, 0, 1);
			this.tableLayoutPanel9.Controls.Add(this.button12, 3, 0);
			this.tableLayoutPanel9.Controls.Add(this.button11, 2, 0);
			this.tableLayoutPanel9.Controls.Add(this.button10, 1, 0);
			this.tableLayoutPanel9.Controls.Add(this.button9, 0, 0);
			this.tableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel9.Location = new System.Drawing.Point(3, 22);
			this.tableLayoutPanel9.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel9.Name = "tableLayoutPanel9";
			this.tableLayoutPanel9.RowCount = 2;
			this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel9.Size = new System.Drawing.Size(626, 167);
			this.tableLayoutPanel9.TabIndex = 0;
			// 
			// button16
			// 
			this.button16.BackColor = System.Drawing.Color.White;
			this.button16.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button16.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button16.Location = new System.Drawing.Point(471, 87);
			this.button16.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button16.Name = "button16";
			this.button16.Size = new System.Drawing.Size(152, 76);
			this.button16.TabIndex = 7;
			this.button16.Text = "음료";
			this.button16.UseVisualStyleBackColor = false;
			this.button16.Click += new System.EventHandler(this.button16_Click);
			// 
			// button15
			// 
			this.button15.BackColor = System.Drawing.Color.White;
			this.button15.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button15.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button15.Location = new System.Drawing.Point(315, 87);
			this.button15.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button15.Name = "button15";
			this.button15.Size = new System.Drawing.Size(150, 76);
			this.button15.TabIndex = 6;
			this.button15.Text = "치킨텐더";
			this.button15.UseVisualStyleBackColor = false;
			this.button15.Click += new System.EventHandler(this.button15_Click);
			// 
			// button14
			// 
			this.button14.BackColor = System.Drawing.Color.White;
			this.button14.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button14.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button14.Location = new System.Drawing.Point(159, 87);
			this.button14.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button14.Name = "button14";
			this.button14.Size = new System.Drawing.Size(150, 76);
			this.button14.TabIndex = 5;
			this.button14.Text = "웨지감자";
			this.button14.UseVisualStyleBackColor = false;
			this.button14.Click += new System.EventHandler(this.button14_Click);
			// 
			// button13
			// 
			this.button13.BackColor = System.Drawing.Color.White;
			this.button13.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button13.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button13.Location = new System.Drawing.Point(3, 87);
			this.button13.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button13.Name = "button13";
			this.button13.Size = new System.Drawing.Size(150, 76);
			this.button13.TabIndex = 4;
			this.button13.Text = "오븐 스파게티";
			this.button13.UseVisualStyleBackColor = false;
			this.button13.Click += new System.EventHandler(this.button13_Click);
			// 
			// button12
			// 
			this.button12.BackColor = System.Drawing.Color.White;
			this.button12.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button12.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button12.Location = new System.Drawing.Point(471, 4);
			this.button12.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button12.Name = "button12";
			this.button12.Size = new System.Drawing.Size(152, 75);
			this.button12.TabIndex = 3;
			this.button12.Text = "핫소스";
			this.button12.UseVisualStyleBackColor = false;
			this.button12.Click += new System.EventHandler(this.button12_Click);
			// 
			// button11
			// 
			this.button11.BackColor = System.Drawing.Color.White;
			this.button11.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button11.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button11.Location = new System.Drawing.Point(315, 4);
			this.button11.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button11.Name = "button11";
			this.button11.Size = new System.Drawing.Size(150, 75);
			this.button11.TabIndex = 2;
			this.button11.Text = "올리브";
			this.button11.UseVisualStyleBackColor = false;
			this.button11.Click += new System.EventHandler(this.button11_Click);
			// 
			// button10
			// 
			this.button10.BackColor = System.Drawing.Color.White;
			this.button10.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button10.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button10.Location = new System.Drawing.Point(159, 4);
			this.button10.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button10.Name = "button10";
			this.button10.Size = new System.Drawing.Size(150, 75);
			this.button10.TabIndex = 1;
			this.button10.Text = "갈릭소스";
			this.button10.UseVisualStyleBackColor = false;
			this.button10.Click += new System.EventHandler(this.button10_Click);
			// 
			// button9
			// 
			this.button9.BackColor = System.Drawing.Color.White;
			this.button9.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button9.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button9.Location = new System.Drawing.Point(3, 4);
			this.button9.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button9.Name = "button9";
			this.button9.Size = new System.Drawing.Size(150, 75);
			this.button9.TabIndex = 0;
			this.button9.Text = "치즈 크러스트";
			this.button9.UseVisualStyleBackColor = false;
			this.button9.Click += new System.EventHandler(this.button9_Click);
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.tableLayoutPanel10);
			this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox2.Location = new System.Drawing.Point(3, 4);
			this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.groupBox2.Size = new System.Drawing.Size(632, 193);
			this.groupBox2.TabIndex = 0;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "피자";
			// 
			// tableLayoutPanel10
			// 
			this.tableLayoutPanel10.ColumnCount = 4;
			this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel10.Controls.Add(this.button8, 3, 1);
			this.tableLayoutPanel10.Controls.Add(this.button7, 2, 1);
			this.tableLayoutPanel10.Controls.Add(this.button6, 1, 1);
			this.tableLayoutPanel10.Controls.Add(this.button5, 0, 1);
			this.tableLayoutPanel10.Controls.Add(this.button4, 3, 0);
			this.tableLayoutPanel10.Controls.Add(this.button3, 2, 0);
			this.tableLayoutPanel10.Controls.Add(this.button2, 1, 0);
			this.tableLayoutPanel10.Controls.Add(this.button1, 0, 0);
			this.tableLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel10.Location = new System.Drawing.Point(3, 22);
			this.tableLayoutPanel10.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel10.Name = "tableLayoutPanel10";
			this.tableLayoutPanel10.RowCount = 2;
			this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel10.Size = new System.Drawing.Size(626, 167);
			this.tableLayoutPanel10.TabIndex = 0;
			// 
			// button8
			// 
			this.button8.BackColor = System.Drawing.Color.White;
			this.button8.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button8.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button8.Location = new System.Drawing.Point(471, 87);
			this.button8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button8.Name = "button8";
			this.button8.Size = new System.Drawing.Size(152, 76);
			this.button8.TabIndex = 7;
			this.button8.Text = "치즈피자";
			this.button8.UseVisualStyleBackColor = false;
			this.button8.Click += new System.EventHandler(this.button8_Click);
			// 
			// button7
			// 
			this.button7.BackColor = System.Drawing.Color.White;
			this.button7.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button7.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button7.Location = new System.Drawing.Point(315, 87);
			this.button7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button7.Name = "button7";
			this.button7.Size = new System.Drawing.Size(150, 76);
			this.button7.TabIndex = 6;
			this.button7.Text = "트리플 머쉬룸피자";
			this.button7.UseVisualStyleBackColor = false;
			this.button7.Click += new System.EventHandler(this.button7_Click);
			// 
			// button6
			// 
			this.button6.BackColor = System.Drawing.Color.White;
			this.button6.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button6.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button6.Location = new System.Drawing.Point(159, 87);
			this.button6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button6.Name = "button6";
			this.button6.Size = new System.Drawing.Size(150, 76);
			this.button6.TabIndex = 5;
			this.button6.Text = "쉬림프피자";
			this.button6.UseVisualStyleBackColor = false;
			this.button6.Click += new System.EventHandler(this.button6_Click);
			// 
			// button5
			// 
			this.button5.BackColor = System.Drawing.Color.White;
			this.button5.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button5.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button5.Location = new System.Drawing.Point(3, 87);
			this.button5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button5.Name = "button5";
			this.button5.Size = new System.Drawing.Size(150, 76);
			this.button5.TabIndex = 4;
			this.button5.Text = "고구마피자";
			this.button5.UseVisualStyleBackColor = false;
			this.button5.Click += new System.EventHandler(this.button5_Click);
			// 
			// button4
			// 
			this.button4.BackColor = System.Drawing.Color.White;
			this.button4.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button4.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button4.Location = new System.Drawing.Point(471, 4);
			this.button4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(152, 75);
			this.button4.TabIndex = 3;
			this.button4.Text = "콤비네이션피자";
			this.button4.UseVisualStyleBackColor = false;
			this.button4.Click += new System.EventHandler(this.button4_Click);
			// 
			// button3
			// 
			this.button3.BackColor = System.Drawing.Color.White;
			this.button3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button3.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button3.Location = new System.Drawing.Point(315, 4);
			this.button3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(150, 75);
			this.button3.TabIndex = 2;
			this.button3.Text = "페퍼로니피자";
			this.button3.UseVisualStyleBackColor = false;
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// button2
			// 
			this.button2.BackColor = System.Drawing.Color.White;
			this.button2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button2.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button2.Location = new System.Drawing.Point(159, 4);
			this.button2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(150, 75);
			this.button2.TabIndex = 1;
			this.button2.Text = "포테이토피자";
			this.button2.UseVisualStyleBackColor = false;
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// button1
			// 
			this.button1.BackColor = System.Drawing.Color.White;
			this.button1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button1.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button1.Location = new System.Drawing.Point(3, 4);
			this.button1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(150, 75);
			this.button1.TabIndex = 0;
			this.button1.Text = "불고기피자";
			this.button1.UseVisualStyleBackColor = false;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// tableLayoutPanel3
			// 
			this.tableLayoutPanel3.ColumnCount = 2;
			this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 23F));
			this.tableLayoutPanel3.Controls.Add(this.label2, 1, 0);
			this.tableLayoutPanel3.Controls.Add(this.label1, 0, 0);
			this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 4);
			this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel3.Name = "tableLayoutPanel3";
			this.tableLayoutPanel3.RowCount = 1;
			this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel3.Size = new System.Drawing.Size(1288, 25);
			this.tableLayoutPanel3.TabIndex = 0;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.label2.Font = new System.Drawing.Font("굴림", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.label2.Location = new System.Drawing.Point(647, 0);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(638, 25);
			this.label2.TabIndex = 1;
			this.label2.Text = "시간";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.label1.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.label1.Location = new System.Drawing.Point(3, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(638, 25);
			this.label1.TabIndex = 2;
			this.label1.Text = "직원";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// tabPage2
			// 
			this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(228)))), ((int)(((byte)(242)))));
			this.tabPage2.Controls.Add(this.tableLayoutPanel11);
			this.tabPage2.Location = new System.Drawing.Point(4, 25);
			this.tabPage2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tabPage2.Size = new System.Drawing.Size(1299, 661);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "계산";
			// 
			// tableLayoutPanel11
			// 
			this.tableLayoutPanel11.ColumnCount = 1;
			this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 23F));
			this.tableLayoutPanel11.Controls.Add(this.tableLayoutPanel14, 0, 1);
			this.tableLayoutPanel11.Controls.Add(this.tableLayoutPanel12, 0, 0);
			this.tableLayoutPanel11.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel11.Location = new System.Drawing.Point(3, 4);
			this.tableLayoutPanel11.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel11.Name = "tableLayoutPanel11";
			this.tableLayoutPanel11.RowCount = 2;
			this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40.96601F));
			this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 59.03399F));
			this.tableLayoutPanel11.Size = new System.Drawing.Size(1293, 653);
			this.tableLayoutPanel11.TabIndex = 1;
			// 
			// tableLayoutPanel14
			// 
			this.tableLayoutPanel14.ColumnCount = 2;
			this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel14.Controls.Add(this.groupBox6, 1, 0);
			this.tableLayoutPanel14.Controls.Add(this.groupBox5, 0, 0);
			this.tableLayoutPanel14.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel14.Location = new System.Drawing.Point(3, 271);
			this.tableLayoutPanel14.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel14.Name = "tableLayoutPanel14";
			this.tableLayoutPanel14.RowCount = 1;
			this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 376F));
			this.tableLayoutPanel14.Size = new System.Drawing.Size(1287, 378);
			this.tableLayoutPanel14.TabIndex = 1;
			// 
			// groupBox6
			// 
			this.groupBox6.Controls.Add(this.tableLayoutPanel15);
			this.groupBox6.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox6.Location = new System.Drawing.Point(646, 4);
			this.groupBox6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.groupBox6.Name = "groupBox6";
			this.groupBox6.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.groupBox6.Size = new System.Drawing.Size(638, 370);
			this.groupBox6.TabIndex = 1;
			this.groupBox6.TabStop = false;
			this.groupBox6.Text = "받은금액";
			// 
			// tableLayoutPanel15
			// 
			this.tableLayoutPanel15.ColumnCount = 3;
			this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
			this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
			this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
			this.tableLayoutPanel15.Controls.Add(this.button35, 2, 2);
			this.tableLayoutPanel15.Controls.Add(this.button34, 1, 2);
			this.tableLayoutPanel15.Controls.Add(this.button33, 0, 2);
			this.tableLayoutPanel15.Controls.Add(this.button32, 2, 1);
			this.tableLayoutPanel15.Controls.Add(this.button31, 1, 1);
			this.tableLayoutPanel15.Controls.Add(this.button30, 0, 1);
			this.tableLayoutPanel15.Controls.Add(this.button29, 2, 0);
			this.tableLayoutPanel15.Controls.Add(this.button28, 1, 0);
			this.tableLayoutPanel15.Controls.Add(this.button27, 0, 0);
			this.tableLayoutPanel15.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel15.Location = new System.Drawing.Point(3, 22);
			this.tableLayoutPanel15.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel15.Name = "tableLayoutPanel15";
			this.tableLayoutPanel15.RowCount = 3;
			this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
			this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
			this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
			this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.tableLayoutPanel15.Size = new System.Drawing.Size(632, 344);
			this.tableLayoutPanel15.TabIndex = 0;
			// 
			// button35
			// 
			this.button35.BackColor = System.Drawing.Color.White;
			this.button35.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button35.Font = new System.Drawing.Font("굴림", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button35.Location = new System.Drawing.Point(423, 232);
			this.button35.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button35.Name = "button35";
			this.button35.Size = new System.Drawing.Size(206, 108);
			this.button35.TabIndex = 8;
			this.button35.Text = "Clear";
			this.button35.UseVisualStyleBackColor = false;
			this.button35.Click += new System.EventHandler(this.button35_Click);
			// 
			// button34
			// 
			this.button34.BackColor = System.Drawing.Color.White;
			this.button34.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button34.Font = new System.Drawing.Font("굴림", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button34.Location = new System.Drawing.Point(213, 232);
			this.button34.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button34.Name = "button34";
			this.button34.Size = new System.Drawing.Size(204, 108);
			this.button34.TabIndex = 7;
			this.button34.Text = "100";
			this.button34.UseVisualStyleBackColor = false;
			this.button34.Click += new System.EventHandler(this.button34_Click);
			// 
			// button33
			// 
			this.button33.BackColor = System.Drawing.Color.White;
			this.button33.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button33.Font = new System.Drawing.Font("굴림", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button33.Location = new System.Drawing.Point(3, 232);
			this.button33.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button33.Name = "button33";
			this.button33.Size = new System.Drawing.Size(204, 108);
			this.button33.TabIndex = 6;
			this.button33.Text = "500";
			this.button33.UseVisualStyleBackColor = false;
			this.button33.Click += new System.EventHandler(this.button33_Click);
			// 
			// button32
			// 
			this.button32.BackColor = System.Drawing.Color.White;
			this.button32.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button32.Font = new System.Drawing.Font("굴림", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button32.Location = new System.Drawing.Point(423, 118);
			this.button32.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button32.Name = "button32";
			this.button32.Size = new System.Drawing.Size(206, 106);
			this.button32.TabIndex = 5;
			this.button32.Text = "1000";
			this.button32.UseVisualStyleBackColor = false;
			this.button32.Click += new System.EventHandler(this.button32_Click);
			// 
			// button31
			// 
			this.button31.BackColor = System.Drawing.Color.White;
			this.button31.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button31.Font = new System.Drawing.Font("굴림", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button31.Location = new System.Drawing.Point(213, 118);
			this.button31.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button31.Name = "button31";
			this.button31.Size = new System.Drawing.Size(204, 106);
			this.button31.TabIndex = 4;
			this.button31.Text = "5000";
			this.button31.UseVisualStyleBackColor = false;
			this.button31.Click += new System.EventHandler(this.button31_Click);
			// 
			// button30
			// 
			this.button30.BackColor = System.Drawing.Color.White;
			this.button30.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button30.Font = new System.Drawing.Font("굴림", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button30.Location = new System.Drawing.Point(3, 118);
			this.button30.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button30.Name = "button30";
			this.button30.Size = new System.Drawing.Size(204, 106);
			this.button30.TabIndex = 3;
			this.button30.Text = "10000";
			this.button30.UseVisualStyleBackColor = false;
			this.button30.Click += new System.EventHandler(this.button30_Click);
			// 
			// button29
			// 
			this.button29.BackColor = System.Drawing.Color.White;
			this.button29.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button29.Font = new System.Drawing.Font("굴림", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button29.Location = new System.Drawing.Point(423, 4);
			this.button29.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button29.Name = "button29";
			this.button29.Size = new System.Drawing.Size(206, 106);
			this.button29.TabIndex = 2;
			this.button29.Text = "20000";
			this.button29.UseVisualStyleBackColor = false;
			this.button29.Click += new System.EventHandler(this.button29_Click);
			// 
			// button28
			// 
			this.button28.BackColor = System.Drawing.Color.White;
			this.button28.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button28.Font = new System.Drawing.Font("굴림", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button28.Location = new System.Drawing.Point(213, 4);
			this.button28.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button28.Name = "button28";
			this.button28.Size = new System.Drawing.Size(204, 106);
			this.button28.TabIndex = 1;
			this.button28.Text = "30000";
			this.button28.UseVisualStyleBackColor = false;
			this.button28.Click += new System.EventHandler(this.button28_Click);
			// 
			// button27
			// 
			this.button27.BackColor = System.Drawing.Color.White;
			this.button27.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button27.Font = new System.Drawing.Font("굴림", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button27.Location = new System.Drawing.Point(3, 4);
			this.button27.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button27.Name = "button27";
			this.button27.Size = new System.Drawing.Size(204, 106);
			this.button27.TabIndex = 0;
			this.button27.Text = "50000";
			this.button27.UseVisualStyleBackColor = false;
			this.button27.Click += new System.EventHandler(this.button27_Click);
			// 
			// groupBox5
			// 
			this.groupBox5.Controls.Add(this.tableLayoutPanel16);
			this.groupBox5.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox5.Location = new System.Drawing.Point(3, 4);
			this.groupBox5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.groupBox5.Name = "groupBox5";
			this.groupBox5.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.groupBox5.Size = new System.Drawing.Size(637, 370);
			this.groupBox5.TabIndex = 0;
			this.groupBox5.TabStop = false;
			this.groupBox5.Text = "주문금액";
			// 
			// tableLayoutPanel16
			// 
			this.tableLayoutPanel16.ColumnCount = 2;
			this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel16.Controls.Add(this.label8, 0, 4);
			this.tableLayoutPanel16.Controls.Add(this.textBox4, 1, 2);
			this.tableLayoutPanel16.Controls.Add(this.textBox5, 1, 1);
			this.tableLayoutPanel16.Controls.Add(this.label4, 0, 0);
			this.tableLayoutPanel16.Controls.Add(this.label3, 0, 1);
			this.tableLayoutPanel16.Controls.Add(this.label9, 0, 2);
			this.tableLayoutPanel16.Controls.Add(this.textBox6, 1, 0);
			this.tableLayoutPanel16.Controls.Add(this.label10, 0, 3);
			this.tableLayoutPanel16.Controls.Add(this.textBox7, 1, 3);
			this.tableLayoutPanel16.Controls.Add(this.textBox8, 1, 4);
			this.tableLayoutPanel16.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel16.Location = new System.Drawing.Point(3, 22);
			this.tableLayoutPanel16.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel16.Name = "tableLayoutPanel16";
			this.tableLayoutPanel16.RowCount = 5;
			this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
			this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
			this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
			this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
			this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66666F));
			this.tableLayoutPanel16.Size = new System.Drawing.Size(631, 344);
			this.tableLayoutPanel16.TabIndex = 1;
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
			this.label8.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.label8.Location = new System.Drawing.Point(3, 272);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(309, 72);
			this.label8.TabIndex = 9;
			this.label8.Text = "거스름돈";
			this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// textBox4
			// 
			this.textBox4.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBox4.Font = new System.Drawing.Font("굴림", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.textBox4.Location = new System.Drawing.Point(318, 140);
			this.textBox4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.textBox4.Multiline = true;
			this.textBox4.Name = "textBox4";
			this.textBox4.Size = new System.Drawing.Size(310, 60);
			this.textBox4.TabIndex = 7;
			this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// textBox5
			// 
			this.textBox5.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBox5.Font = new System.Drawing.Font("굴림", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.textBox5.Location = new System.Drawing.Point(318, 72);
			this.textBox5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.textBox5.Multiline = true;
			this.textBox5.Name = "textBox5";
			this.textBox5.Size = new System.Drawing.Size(310, 60);
			this.textBox5.TabIndex = 6;
			this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
			this.label4.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.label4.Location = new System.Drawing.Point(3, 0);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(309, 68);
			this.label4.TabIndex = 0;
			this.label4.Text = "총금액";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.label3.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.label3.Location = new System.Drawing.Point(3, 68);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(309, 68);
			this.label3.TabIndex = 1;
			this.label3.Text = "할인금액";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
			this.label9.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.label9.Location = new System.Drawing.Point(3, 136);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(309, 68);
			this.label9.TabIndex = 2;
			this.label9.Text = "할인후금액";
			this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// textBox6
			// 
			this.textBox6.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBox6.Font = new System.Drawing.Font("굴림", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.textBox6.Location = new System.Drawing.Point(318, 4);
			this.textBox6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.textBox6.Multiline = true;
			this.textBox6.Name = "textBox6";
			this.textBox6.Size = new System.Drawing.Size(310, 60);
			this.textBox6.TabIndex = 5;
			this.textBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Dock = System.Windows.Forms.DockStyle.Fill;
			this.label10.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.label10.Location = new System.Drawing.Point(3, 204);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(309, 68);
			this.label10.TabIndex = 8;
			this.label10.Text = "받은금액";
			this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// textBox7
			// 
			this.textBox7.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBox7.Font = new System.Drawing.Font("굴림", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.textBox7.Location = new System.Drawing.Point(318, 208);
			this.textBox7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.textBox7.Multiline = true;
			this.textBox7.Name = "textBox7";
			this.textBox7.Size = new System.Drawing.Size(310, 60);
			this.textBox7.TabIndex = 10;
			this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// textBox8
			// 
			this.textBox8.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBox8.Font = new System.Drawing.Font("굴림", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.textBox8.Location = new System.Drawing.Point(318, 276);
			this.textBox8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.textBox8.Multiline = true;
			this.textBox8.Name = "textBox8";
			this.textBox8.Size = new System.Drawing.Size(310, 64);
			this.textBox8.TabIndex = 11;
			this.textBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// tableLayoutPanel12
			// 
			this.tableLayoutPanel12.ColumnCount = 3;
			this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.67F));
			this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33F));
			this.tableLayoutPanel12.Controls.Add(this.tableLayoutPanel13, 2, 0);
			this.tableLayoutPanel12.Controls.Add(this.dataGridView2, 0, 0);
			this.tableLayoutPanel12.Controls.Add(this.tableLayoutPanel42, 1, 0);
			this.tableLayoutPanel12.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel12.Location = new System.Drawing.Point(3, 4);
			this.tableLayoutPanel12.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel12.Name = "tableLayoutPanel12";
			this.tableLayoutPanel12.RowCount = 1;
			this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel12.Size = new System.Drawing.Size(1287, 259);
			this.tableLayoutPanel12.TabIndex = 2;
			// 
			// tableLayoutPanel13
			// 
			this.tableLayoutPanel13.ColumnCount = 2;
			this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel13.Controls.Add(this.tableLayoutPanel32, 0, 0);
			this.tableLayoutPanel13.Controls.Add(this.tableLayoutPanel33, 1, 0);
			this.tableLayoutPanel13.Controls.Add(this.tableLayoutPanel34, 0, 1);
			this.tableLayoutPanel13.Controls.Add(this.tableLayoutPanel35, 1, 1);
			this.tableLayoutPanel13.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel13.Location = new System.Drawing.Point(860, 4);
			this.tableLayoutPanel13.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel13.Name = "tableLayoutPanel13";
			this.tableLayoutPanel13.RowCount = 2;
			this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
			this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 66.66666F));
			this.tableLayoutPanel13.Size = new System.Drawing.Size(424, 251);
			this.tableLayoutPanel13.TabIndex = 1;
			// 
			// tableLayoutPanel32
			// 
			this.tableLayoutPanel32.ColumnCount = 1;
			this.tableLayoutPanel32.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel32.Controls.Add(this.button23, 0, 0);
			this.tableLayoutPanel32.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel32.Location = new System.Drawing.Point(3, 4);
			this.tableLayoutPanel32.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel32.Name = "tableLayoutPanel32";
			this.tableLayoutPanel32.RowCount = 1;
			this.tableLayoutPanel32.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel32.Size = new System.Drawing.Size(206, 75);
			this.tableLayoutPanel32.TabIndex = 2;
			// 
			// button23
			// 
			this.button23.BackColor = System.Drawing.Color.White;
			this.button23.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button23.Font = new System.Drawing.Font("굴림", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button23.Location = new System.Drawing.Point(3, 4);
			this.button23.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button23.Name = "button23";
			this.button23.Size = new System.Drawing.Size(200, 67);
			this.button23.TabIndex = 0;
			this.button23.Text = "현금계산";
			this.button23.UseVisualStyleBackColor = false;
			this.button23.Click += new System.EventHandler(this.button23_Click);
			// 
			// tableLayoutPanel33
			// 
			this.tableLayoutPanel33.ColumnCount = 1;
			this.tableLayoutPanel33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel33.Controls.Add(this.button24, 0, 0);
			this.tableLayoutPanel33.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel33.Location = new System.Drawing.Point(215, 4);
			this.tableLayoutPanel33.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel33.Name = "tableLayoutPanel33";
			this.tableLayoutPanel33.RowCount = 1;
			this.tableLayoutPanel33.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel33.Size = new System.Drawing.Size(206, 75);
			this.tableLayoutPanel33.TabIndex = 3;
			// 
			// button24
			// 
			this.button24.BackColor = System.Drawing.Color.White;
			this.button24.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button24.Font = new System.Drawing.Font("굴림", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button24.Location = new System.Drawing.Point(3, 4);
			this.button24.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button24.Name = "button24";
			this.button24.Size = new System.Drawing.Size(200, 67);
			this.button24.TabIndex = 1;
			this.button24.Text = "카드계산";
			this.button24.UseVisualStyleBackColor = false;
			this.button24.Click += new System.EventHandler(this.button24_Click);
			// 
			// tableLayoutPanel34
			// 
			this.tableLayoutPanel34.ColumnCount = 1;
			this.tableLayoutPanel34.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel34.Controls.Add(this.button22, 0, 0);
			this.tableLayoutPanel34.Controls.Add(this.button25, 0, 1);
			this.tableLayoutPanel34.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel34.Location = new System.Drawing.Point(3, 87);
			this.tableLayoutPanel34.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel34.Name = "tableLayoutPanel34";
			this.tableLayoutPanel34.RowCount = 2;
			this.tableLayoutPanel34.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel34.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel34.Size = new System.Drawing.Size(206, 160);
			this.tableLayoutPanel34.TabIndex = 4;
			// 
			// button22
			// 
			this.button22.BackColor = System.Drawing.Color.White;
			this.button22.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button22.Font = new System.Drawing.Font("굴림", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button22.Location = new System.Drawing.Point(3, 4);
			this.button22.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button22.Name = "button22";
			this.button22.Size = new System.Drawing.Size(200, 72);
			this.button22.TabIndex = 0;
			this.button22.Text = "쿠폰적립 및 사용 ";
			this.button22.UseVisualStyleBackColor = false;
			this.button22.Click += new System.EventHandler(this.button22_Click_1);
			// 
			// button25
			// 
			this.button25.BackColor = System.Drawing.Color.White;
			this.button25.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button25.Font = new System.Drawing.Font("굴림", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button25.Location = new System.Drawing.Point(3, 84);
			this.button25.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button25.Name = "button25";
			this.button25.Size = new System.Drawing.Size(200, 72);
			this.button25.TabIndex = 1;
			this.button25.Text = "쿠폰 계산";
			this.button25.UseVisualStyleBackColor = false;
			this.button25.Click += new System.EventHandler(this.button25_Click);
			// 
			// tableLayoutPanel35
			// 
			this.tableLayoutPanel35.ColumnCount = 1;
			this.tableLayoutPanel35.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel35.Controls.Add(this.button26, 0, 0);
			this.tableLayoutPanel35.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel35.Location = new System.Drawing.Point(215, 87);
			this.tableLayoutPanel35.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel35.Name = "tableLayoutPanel35";
			this.tableLayoutPanel35.RowCount = 1;
			this.tableLayoutPanel35.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel35.Size = new System.Drawing.Size(206, 160);
			this.tableLayoutPanel35.TabIndex = 5;
			// 
			// button26
			// 
			this.button26.BackColor = System.Drawing.Color.White;
			this.button26.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button26.Font = new System.Drawing.Font("굴림", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button26.Location = new System.Drawing.Point(3, 4);
			this.button26.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button26.Name = "button26";
			this.button26.Size = new System.Drawing.Size(200, 152);
			this.button26.TabIndex = 0;
			this.button26.Text = "영수증";
			this.button26.UseVisualStyleBackColor = false;
			this.button26.Click += new System.EventHandler(this.button26_Click);
			// 
			// dataGridView2
			// 
			this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.dataGridView2.BackgroundColor = System.Drawing.Color.White;
			this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dataGridView2.Location = new System.Drawing.Point(3, 4);
			this.dataGridView2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.dataGridView2.Name = "dataGridView2";
			this.dataGridView2.RowTemplate.Height = 23;
			this.dataGridView2.Size = new System.Drawing.Size(637, 251);
			this.dataGridView2.TabIndex = 0;
			this.dataGridView2.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dataGridView2_RowPostPaint);
			// 
			// tableLayoutPanel42
			// 
			this.tableLayoutPanel42.ColumnCount = 1;
			this.tableLayoutPanel42.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel42.Controls.Add(this.groupBox12, 0, 0);
			this.tableLayoutPanel42.Controls.Add(this.button54, 0, 1);
			this.tableLayoutPanel42.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel42.Location = new System.Drawing.Point(646, 4);
			this.tableLayoutPanel42.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel42.Name = "tableLayoutPanel42";
			this.tableLayoutPanel42.RowCount = 2;
			this.tableLayoutPanel42.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 66.66666F));
			this.tableLayoutPanel42.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
			this.tableLayoutPanel42.Size = new System.Drawing.Size(208, 251);
			this.tableLayoutPanel42.TabIndex = 2;
			// 
			// groupBox12
			// 
			this.groupBox12.Controls.Add(this.textBox20);
			this.groupBox12.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox12.Location = new System.Drawing.Point(3, 4);
			this.groupBox12.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.groupBox12.Name = "groupBox12";
			this.groupBox12.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.groupBox12.Size = new System.Drawing.Size(202, 159);
			this.groupBox12.TabIndex = 2;
			this.groupBox12.TabStop = false;
			this.groupBox12.Text = "배달주소";
			// 
			// textBox20
			// 
			this.textBox20.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBox20.Font = new System.Drawing.Font("굴림", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.textBox20.Location = new System.Drawing.Point(3, 22);
			this.textBox20.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.textBox20.Multiline = true;
			this.textBox20.Name = "textBox20";
			this.textBox20.Size = new System.Drawing.Size(196, 133);
			this.textBox20.TabIndex = 0;
			// 
			// button54
			// 
			this.button54.BackColor = System.Drawing.Color.White;
			this.button54.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button54.Font = new System.Drawing.Font("굴림", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button54.Location = new System.Drawing.Point(3, 171);
			this.button54.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button54.Name = "button54";
			this.button54.Size = new System.Drawing.Size(202, 76);
			this.button54.TabIndex = 3;
			this.button54.Text = "주문취소";
			this.button54.UseVisualStyleBackColor = false;
			this.button54.Click += new System.EventHandler(this.button54_Click_1);
			// 
			// tabPage3
			// 
			this.tabPage3.Controls.Add(this.tableLayoutPanel17);
			this.tabPage3.Location = new System.Drawing.Point(4, 25);
			this.tabPage3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tabPage3.Name = "tabPage3";
			this.tabPage3.Size = new System.Drawing.Size(1299, 661);
			this.tabPage3.TabIndex = 2;
			this.tabPage3.Text = "회원관리";
			this.tabPage3.UseVisualStyleBackColor = true;
			// 
			// tableLayoutPanel17
			// 
			this.tableLayoutPanel17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(228)))), ((int)(((byte)(242)))));
			this.tableLayoutPanel17.ColumnCount = 2;
			this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 72.22222F));
			this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 27.77778F));
			this.tableLayoutPanel17.Controls.Add(this.tableLayoutPanel18, 0, 0);
			this.tableLayoutPanel17.Controls.Add(this.tableLayoutPanel19, 0, 1);
			this.tableLayoutPanel17.Controls.Add(this.tableLayoutPanel22, 1, 0);
			this.tableLayoutPanel17.Controls.Add(this.tableLayoutPanel23, 1, 1);
			this.tableLayoutPanel17.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel17.Location = new System.Drawing.Point(0, 0);
			this.tableLayoutPanel17.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel17.Name = "tableLayoutPanel17";
			this.tableLayoutPanel17.RowCount = 2;
			this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 45.21576F));
			this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 54.78424F));
			this.tableLayoutPanel17.Size = new System.Drawing.Size(1299, 661);
			this.tableLayoutPanel17.TabIndex = 0;
			// 
			// tableLayoutPanel18
			// 
			this.tableLayoutPanel18.ColumnCount = 3;
			this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 2F));
			this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 93F));
			this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel18.Controls.Add(this.dataGridView3, 1, 0);
			this.tableLayoutPanel18.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel18.Location = new System.Drawing.Point(3, 4);
			this.tableLayoutPanel18.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel18.Name = "tableLayoutPanel18";
			this.tableLayoutPanel18.RowCount = 1;
			this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel18.Size = new System.Drawing.Size(932, 290);
			this.tableLayoutPanel18.TabIndex = 0;
			// 
			// dataGridView3
			// 
			this.dataGridView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.dataGridView3.BackgroundColor = System.Drawing.Color.White;
			this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dataGridView3.Location = new System.Drawing.Point(21, 4);
			this.dataGridView3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.dataGridView3.Name = "dataGridView3";
			this.dataGridView3.RowTemplate.Height = 23;
			this.dataGridView3.Size = new System.Drawing.Size(860, 282);
			this.dataGridView3.TabIndex = 0;
			this.dataGridView3.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView3_CellClick);
			this.dataGridView3.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dataGridView3_RowPostPaint);
			// 
			// tableLayoutPanel19
			// 
			this.tableLayoutPanel19.ColumnCount = 3;
			this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 2F));
			this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 93F));
			this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel19.Controls.Add(this.groupBox7, 1, 0);
			this.tableLayoutPanel19.Controls.Add(this.groupBox8, 1, 1);
			this.tableLayoutPanel19.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel19.Location = new System.Drawing.Point(3, 302);
			this.tableLayoutPanel19.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel19.Name = "tableLayoutPanel19";
			this.tableLayoutPanel19.RowCount = 2;
			this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.5122F));
			this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80.48781F));
			this.tableLayoutPanel19.Size = new System.Drawing.Size(932, 355);
			this.tableLayoutPanel19.TabIndex = 1;
			// 
			// groupBox7
			// 
			this.groupBox7.Controls.Add(this.tableLayoutPanel20);
			this.groupBox7.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox7.Location = new System.Drawing.Point(21, 4);
			this.groupBox7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.groupBox7.Name = "groupBox7";
			this.groupBox7.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.groupBox7.Size = new System.Drawing.Size(860, 61);
			this.groupBox7.TabIndex = 0;
			this.groupBox7.TabStop = false;
			this.groupBox7.Text = "이름검색";
			// 
			// tableLayoutPanel20
			// 
			this.tableLayoutPanel20.ColumnCount = 5;
			this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
			this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 31.25F));
			this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 43.75F));
			this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
			this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
			this.tableLayoutPanel20.Controls.Add(this.label11, 1, 0);
			this.tableLayoutPanel20.Controls.Add(this.textBox9, 2, 0);
			this.tableLayoutPanel20.Controls.Add(this.button41, 3, 0);
			this.tableLayoutPanel20.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel20.Location = new System.Drawing.Point(3, 22);
			this.tableLayoutPanel20.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel20.Name = "tableLayoutPanel20";
			this.tableLayoutPanel20.RowCount = 1;
			this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45F));
			this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45F));
			this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45F));
			this.tableLayoutPanel20.Size = new System.Drawing.Size(854, 35);
			this.tableLayoutPanel20.TabIndex = 0;
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
			this.label11.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.label11.Location = new System.Drawing.Point(56, 0);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(260, 45);
			this.label11.TabIndex = 0;
			this.label11.Text = "이름 : ";
			this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// textBox9
			// 
			this.textBox9.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBox9.Font = new System.Drawing.Font("굴림", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.textBox9.Location = new System.Drawing.Point(322, 4);
			this.textBox9.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.textBox9.Multiline = true;
			this.textBox9.Name = "textBox9";
			this.textBox9.Size = new System.Drawing.Size(367, 37);
			this.textBox9.TabIndex = 1;
			// 
			// button41
			// 
			this.button41.BackColor = System.Drawing.Color.White;
			this.button41.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button41.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button41.Location = new System.Drawing.Point(695, 4);
			this.button41.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button41.Name = "button41";
			this.button41.Size = new System.Drawing.Size(100, 37);
			this.button41.TabIndex = 2;
			this.button41.Text = "검색";
			this.button41.UseVisualStyleBackColor = false;
			this.button41.Click += new System.EventHandler(this.button41_Click);
			// 
			// groupBox8
			// 
			this.groupBox8.Controls.Add(this.tableLayoutPanel21);
			this.groupBox8.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox8.Location = new System.Drawing.Point(21, 73);
			this.groupBox8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.groupBox8.Name = "groupBox8";
			this.groupBox8.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.groupBox8.Size = new System.Drawing.Size(860, 278);
			this.groupBox8.TabIndex = 1;
			this.groupBox8.TabStop = false;
			this.groupBox8.Text = "회원정보";
			// 
			// tableLayoutPanel21
			// 
			this.tableLayoutPanel21.ColumnCount = 2;
			this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30.25937F));
			this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 69.74063F));
			this.tableLayoutPanel21.Controls.Add(this.label12, 0, 0);
			this.tableLayoutPanel21.Controls.Add(this.label13, 0, 1);
			this.tableLayoutPanel21.Controls.Add(this.label14, 0, 2);
			this.tableLayoutPanel21.Controls.Add(this.label15, 0, 3);
			this.tableLayoutPanel21.Controls.Add(this.tableLayoutPanel36, 1, 0);
			this.tableLayoutPanel21.Controls.Add(this.tableLayoutPanel37, 1, 1);
			this.tableLayoutPanel21.Controls.Add(this.tableLayoutPanel38, 1, 2);
			this.tableLayoutPanel21.Controls.Add(this.tableLayoutPanel39, 1, 3);
			this.tableLayoutPanel21.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel21.Location = new System.Drawing.Point(3, 22);
			this.tableLayoutPanel21.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel21.Name = "tableLayoutPanel21";
			this.tableLayoutPanel21.RowCount = 4;
			this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel21.Size = new System.Drawing.Size(854, 252);
			this.tableLayoutPanel21.TabIndex = 0;
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Dock = System.Windows.Forms.DockStyle.Fill;
			this.label12.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.label12.Location = new System.Drawing.Point(3, 0);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(252, 63);
			this.label12.TabIndex = 0;
			this.label12.Text = "이름";
			this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label13
			// 
			this.label13.AutoSize = true;
			this.label13.Dock = System.Windows.Forms.DockStyle.Fill;
			this.label13.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.label13.Location = new System.Drawing.Point(3, 63);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(252, 63);
			this.label13.TabIndex = 1;
			this.label13.Text = "전화번호";
			this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label14
			// 
			this.label14.AutoSize = true;
			this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
			this.label14.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.label14.Location = new System.Drawing.Point(3, 126);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(252, 63);
			this.label14.TabIndex = 2;
			this.label14.Text = "생년월일";
			this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label15
			// 
			this.label15.AutoSize = true;
			this.label15.Dock = System.Windows.Forms.DockStyle.Fill;
			this.label15.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.label15.Location = new System.Drawing.Point(3, 189);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(252, 63);
			this.label15.TabIndex = 3;
			this.label15.Text = "쿠폰";
			this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// tableLayoutPanel36
			// 
			this.tableLayoutPanel36.ColumnCount = 2;
			this.tableLayoutPanel36.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
			this.tableLayoutPanel36.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
			this.tableLayoutPanel36.Controls.Add(this.textBox10, 0, 0);
			this.tableLayoutPanel36.Controls.Add(this.groupBox11, 1, 0);
			this.tableLayoutPanel36.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel36.Location = new System.Drawing.Point(261, 4);
			this.tableLayoutPanel36.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel36.Name = "tableLayoutPanel36";
			this.tableLayoutPanel36.RowCount = 1;
			this.tableLayoutPanel36.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel36.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 54F));
			this.tableLayoutPanel36.Size = new System.Drawing.Size(590, 55);
			this.tableLayoutPanel36.TabIndex = 4;
			// 
			// textBox10
			// 
			this.textBox10.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBox10.Font = new System.Drawing.Font("굴림", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.textBox10.Location = new System.Drawing.Point(3, 4);
			this.textBox10.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.textBox10.Multiline = true;
			this.textBox10.Name = "textBox10";
			this.textBox10.Size = new System.Drawing.Size(348, 47);
			this.textBox10.TabIndex = 1;
			// 
			// groupBox11
			// 
			this.groupBox11.Controls.Add(this.tableLayoutPanel40);
			this.groupBox11.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox11.Location = new System.Drawing.Point(357, 4);
			this.groupBox11.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.groupBox11.Name = "groupBox11";
			this.groupBox11.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.groupBox11.Size = new System.Drawing.Size(230, 47);
			this.groupBox11.TabIndex = 2;
			this.groupBox11.TabStop = false;
			this.groupBox11.Text = "성별";
			// 
			// tableLayoutPanel40
			// 
			this.tableLayoutPanel40.ColumnCount = 2;
			this.tableLayoutPanel40.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel40.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel40.Controls.Add(this.radioButton1, 0, 0);
			this.tableLayoutPanel40.Controls.Add(this.radioButton2, 1, 0);
			this.tableLayoutPanel40.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel40.Location = new System.Drawing.Point(3, 22);
			this.tableLayoutPanel40.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel40.Name = "tableLayoutPanel40";
			this.tableLayoutPanel40.RowCount = 1;
			this.tableLayoutPanel40.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel40.Size = new System.Drawing.Size(224, 21);
			this.tableLayoutPanel40.TabIndex = 0;
			// 
			// radioButton1
			// 
			this.radioButton1.AutoSize = true;
			this.radioButton1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.radioButton1.Location = new System.Drawing.Point(3, 4);
			this.radioButton1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.radioButton1.Name = "radioButton1";
			this.radioButton1.Size = new System.Drawing.Size(106, 13);
			this.radioButton1.TabIndex = 0;
			this.radioButton1.TabStop = true;
			this.radioButton1.Text = "남자";
			this.radioButton1.UseVisualStyleBackColor = true;
			// 
			// radioButton2
			// 
			this.radioButton2.AutoSize = true;
			this.radioButton2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.radioButton2.Location = new System.Drawing.Point(115, 4);
			this.radioButton2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.radioButton2.Name = "radioButton2";
			this.radioButton2.Size = new System.Drawing.Size(106, 13);
			this.radioButton2.TabIndex = 1;
			this.radioButton2.TabStop = true;
			this.radioButton2.Text = "여자";
			this.radioButton2.UseVisualStyleBackColor = true;
			// 
			// tableLayoutPanel37
			// 
			this.tableLayoutPanel37.ColumnCount = 1;
			this.tableLayoutPanel37.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel37.Controls.Add(this.textBox11, 0, 0);
			this.tableLayoutPanel37.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel37.Location = new System.Drawing.Point(261, 67);
			this.tableLayoutPanel37.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel37.Name = "tableLayoutPanel37";
			this.tableLayoutPanel37.RowCount = 1;
			this.tableLayoutPanel37.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel37.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 54F));
			this.tableLayoutPanel37.Size = new System.Drawing.Size(590, 55);
			this.tableLayoutPanel37.TabIndex = 5;
			// 
			// textBox11
			// 
			this.textBox11.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBox11.Font = new System.Drawing.Font("굴림", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.textBox11.Location = new System.Drawing.Point(3, 4);
			this.textBox11.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.textBox11.Multiline = true;
			this.textBox11.Name = "textBox11";
			this.textBox11.Size = new System.Drawing.Size(584, 47);
			this.textBox11.TabIndex = 0;
			// 
			// tableLayoutPanel38
			// 
			this.tableLayoutPanel38.ColumnCount = 1;
			this.tableLayoutPanel38.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel38.Controls.Add(this.textBox12, 0, 0);
			this.tableLayoutPanel38.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel38.Location = new System.Drawing.Point(261, 130);
			this.tableLayoutPanel38.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel38.Name = "tableLayoutPanel38";
			this.tableLayoutPanel38.RowCount = 1;
			this.tableLayoutPanel38.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel38.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 54F));
			this.tableLayoutPanel38.Size = new System.Drawing.Size(590, 55);
			this.tableLayoutPanel38.TabIndex = 6;
			// 
			// textBox12
			// 
			this.textBox12.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBox12.Font = new System.Drawing.Font("굴림", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.textBox12.Location = new System.Drawing.Point(3, 4);
			this.textBox12.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.textBox12.Multiline = true;
			this.textBox12.Name = "textBox12";
			this.textBox12.Size = new System.Drawing.Size(584, 47);
			this.textBox12.TabIndex = 0;
			// 
			// tableLayoutPanel39
			// 
			this.tableLayoutPanel39.ColumnCount = 1;
			this.tableLayoutPanel39.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel39.Controls.Add(this.textBox13, 0, 0);
			this.tableLayoutPanel39.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel39.Location = new System.Drawing.Point(261, 193);
			this.tableLayoutPanel39.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel39.Name = "tableLayoutPanel39";
			this.tableLayoutPanel39.RowCount = 1;
			this.tableLayoutPanel39.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel39.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 56F));
			this.tableLayoutPanel39.Size = new System.Drawing.Size(590, 55);
			this.tableLayoutPanel39.TabIndex = 7;
			// 
			// textBox13
			// 
			this.textBox13.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBox13.Font = new System.Drawing.Font("굴림", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.textBox13.Location = new System.Drawing.Point(3, 4);
			this.textBox13.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.textBox13.Multiline = true;
			this.textBox13.Name = "textBox13";
			this.textBox13.Size = new System.Drawing.Size(584, 47);
			this.textBox13.TabIndex = 0;
			// 
			// tableLayoutPanel22
			// 
			this.tableLayoutPanel22.ColumnCount = 1;
			this.tableLayoutPanel22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel22.Controls.Add(this.button42, 0, 0);
			this.tableLayoutPanel22.Controls.Add(this.button43, 0, 3);
			this.tableLayoutPanel22.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel22.Location = new System.Drawing.Point(941, 4);
			this.tableLayoutPanel22.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel22.Name = "tableLayoutPanel22";
			this.tableLayoutPanel22.RowCount = 4;
			this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 45F));
			this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
			this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 45F));
			this.tableLayoutPanel22.Size = new System.Drawing.Size(355, 290);
			this.tableLayoutPanel22.TabIndex = 2;
			this.tableLayoutPanel22.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel22_Paint);
			// 
			// button42
			// 
			this.button42.BackColor = System.Drawing.Color.White;
			this.button42.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button42.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button42.Location = new System.Drawing.Point(3, 4);
			this.button42.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button42.Name = "button42";
			this.button42.Size = new System.Drawing.Size(349, 122);
			this.button42.TabIndex = 0;
			this.button42.Text = "쿠폰적립";
			this.button42.UseVisualStyleBackColor = false;
			this.button42.Click += new System.EventHandler(this.button42_Click);
			// 
			// button43
			// 
			this.button43.BackColor = System.Drawing.Color.White;
			this.button43.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button43.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button43.Location = new System.Drawing.Point(3, 162);
			this.button43.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button43.Name = "button43";
			this.button43.Size = new System.Drawing.Size(349, 124);
			this.button43.TabIndex = 1;
			this.button43.Text = "쿠폰사용";
			this.button43.UseVisualStyleBackColor = false;
			this.button43.Click += new System.EventHandler(this.button43_Click);
			// 
			// tableLayoutPanel23
			// 
			this.tableLayoutPanel23.ColumnCount = 1;
			this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel23.Controls.Add(this.button47, 0, 3);
			this.tableLayoutPanel23.Controls.Add(this.button46, 0, 2);
			this.tableLayoutPanel23.Controls.Add(this.button45, 0, 1);
			this.tableLayoutPanel23.Controls.Add(this.button44, 0, 0);
			this.tableLayoutPanel23.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel23.Location = new System.Drawing.Point(941, 302);
			this.tableLayoutPanel23.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel23.Name = "tableLayoutPanel23";
			this.tableLayoutPanel23.RowCount = 4;
			this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel23.Size = new System.Drawing.Size(355, 355);
			this.tableLayoutPanel23.TabIndex = 3;
			// 
			// button47
			// 
			this.button47.BackColor = System.Drawing.Color.White;
			this.button47.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button47.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button47.Location = new System.Drawing.Point(3, 268);
			this.button47.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button47.Name = "button47";
			this.button47.Size = new System.Drawing.Size(349, 83);
			this.button47.TabIndex = 3;
			this.button47.Text = "회원삭제";
			this.button47.UseVisualStyleBackColor = false;
			this.button47.Click += new System.EventHandler(this.button47_Click);
			// 
			// button46
			// 
			this.button46.BackColor = System.Drawing.Color.White;
			this.button46.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button46.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button46.Location = new System.Drawing.Point(3, 180);
			this.button46.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button46.Name = "button46";
			this.button46.Size = new System.Drawing.Size(349, 80);
			this.button46.TabIndex = 2;
			this.button46.Text = "회원수정";
			this.button46.UseVisualStyleBackColor = false;
			this.button46.Click += new System.EventHandler(this.button46_Click);
			// 
			// button45
			// 
			this.button45.BackColor = System.Drawing.Color.White;
			this.button45.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button45.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button45.Location = new System.Drawing.Point(3, 92);
			this.button45.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button45.Name = "button45";
			this.button45.Size = new System.Drawing.Size(349, 80);
			this.button45.TabIndex = 1;
			this.button45.Text = "회원등록";
			this.button45.UseVisualStyleBackColor = false;
			this.button45.Click += new System.EventHandler(this.button45_Click);
			// 
			// button44
			// 
			this.button44.BackColor = System.Drawing.Color.White;
			this.button44.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button44.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button44.Location = new System.Drawing.Point(3, 4);
			this.button44.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button44.Name = "button44";
			this.button44.Size = new System.Drawing.Size(349, 80);
			this.button44.TabIndex = 0;
			this.button44.Text = "전체회원";
			this.button44.UseVisualStyleBackColor = false;
			this.button44.Click += new System.EventHandler(this.button44_Click);
			// 
			// tabPage4
			// 
			this.tabPage4.Controls.Add(this.tableLayoutPanel24);
			this.tabPage4.Location = new System.Drawing.Point(4, 25);
			this.tabPage4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tabPage4.Name = "tabPage4";
			this.tabPage4.Size = new System.Drawing.Size(1300, 660);
			this.tabPage4.TabIndex = 3;
			this.tabPage4.Text = "매출관리";
			this.tabPage4.UseVisualStyleBackColor = true;
			// 
			// tableLayoutPanel24
			// 
			this.tableLayoutPanel24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(228)))), ((int)(((byte)(242)))));
			this.tableLayoutPanel24.ColumnCount = 2;
			this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel24.Controls.Add(this.tableLayoutPanel25, 1, 0);
			this.tableLayoutPanel24.Controls.Add(this.tableLayoutPanel28, 0, 0);
			this.tableLayoutPanel24.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel24.Location = new System.Drawing.Point(0, 0);
			this.tableLayoutPanel24.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.tableLayoutPanel24.Name = "tableLayoutPanel24";
			this.tableLayoutPanel24.RowCount = 1;
			this.tableLayoutPanel24.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel24.Size = new System.Drawing.Size(1300, 660);
			this.tableLayoutPanel24.TabIndex = 0;
			// 
			// tableLayoutPanel25
			// 
			this.tableLayoutPanel25.ColumnCount = 1;
			this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel25.Controls.Add(this.groupBox9, 0, 0);
			this.tableLayoutPanel25.Controls.Add(this.groupBox10, 0, 1);
			this.tableLayoutPanel25.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel25.Location = new System.Drawing.Point(653, 2);
			this.tableLayoutPanel25.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.tableLayoutPanel25.Name = "tableLayoutPanel25";
			this.tableLayoutPanel25.RowCount = 2;
			this.tableLayoutPanel25.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel25.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel25.Size = new System.Drawing.Size(644, 656);
			this.tableLayoutPanel25.TabIndex = 1;
			// 
			// groupBox9
			// 
			this.groupBox9.Controls.Add(this.tableLayoutPanel26);
			this.groupBox9.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox9.Location = new System.Drawing.Point(3, 2);
			this.groupBox9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.groupBox9.Name = "groupBox9";
			this.groupBox9.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.groupBox9.Size = new System.Drawing.Size(638, 324);
			this.groupBox9.TabIndex = 0;
			this.groupBox9.TabStop = false;
			this.groupBox9.Text = "날짜";
			// 
			// tableLayoutPanel26
			// 
			this.tableLayoutPanel26.ColumnCount = 2;
			this.tableLayoutPanel26.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel26.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel26.Controls.Add(this.label16, 0, 0);
			this.tableLayoutPanel26.Controls.Add(this.label17, 0, 1);
			this.tableLayoutPanel26.Controls.Add(this.label18, 0, 2);
			this.tableLayoutPanel26.Controls.Add(this.textBox14, 1, 0);
			this.tableLayoutPanel26.Controls.Add(this.textBox15, 1, 1);
			this.tableLayoutPanel26.Controls.Add(this.textBox16, 1, 2);
			this.tableLayoutPanel26.Controls.Add(this.label20, 0, 3);
			this.tableLayoutPanel26.Controls.Add(this.textBox17, 1, 3);
			this.tableLayoutPanel26.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel26.Location = new System.Drawing.Point(3, 20);
			this.tableLayoutPanel26.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.tableLayoutPanel26.Name = "tableLayoutPanel26";
			this.tableLayoutPanel26.RowCount = 4;
			this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
			this.tableLayoutPanel26.Size = new System.Drawing.Size(632, 302);
			this.tableLayoutPanel26.TabIndex = 0;
			// 
			// label16
			// 
			this.label16.AutoSize = true;
			this.label16.Dock = System.Windows.Forms.DockStyle.Fill;
			this.label16.Font = new System.Drawing.Font("굴림", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.label16.Location = new System.Drawing.Point(3, 0);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(310, 75);
			this.label16.TabIndex = 0;
			this.label16.Text = "판매날짜";
			this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label17
			// 
			this.label17.AutoSize = true;
			this.label17.Dock = System.Windows.Forms.DockStyle.Fill;
			this.label17.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.label17.Location = new System.Drawing.Point(3, 75);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(310, 75);
			this.label17.TabIndex = 1;
			this.label17.Text = "판매월";
			this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label18
			// 
			this.label18.AutoSize = true;
			this.label18.Dock = System.Windows.Forms.DockStyle.Fill;
			this.label18.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.label18.Location = new System.Drawing.Point(3, 150);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(310, 75);
			this.label18.TabIndex = 2;
			this.label18.Text = "판매년도";
			this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// textBox14
			// 
			this.textBox14.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBox14.Font = new System.Drawing.Font("굴림", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.textBox14.Location = new System.Drawing.Point(319, 2);
			this.textBox14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.textBox14.Multiline = true;
			this.textBox14.Name = "textBox14";
			this.textBox14.Size = new System.Drawing.Size(310, 71);
			this.textBox14.TabIndex = 3;
			// 
			// textBox15
			// 
			this.textBox15.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBox15.Font = new System.Drawing.Font("굴림", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.textBox15.Location = new System.Drawing.Point(319, 77);
			this.textBox15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.textBox15.Multiline = true;
			this.textBox15.Name = "textBox15";
			this.textBox15.Size = new System.Drawing.Size(310, 71);
			this.textBox15.TabIndex = 4;
			// 
			// textBox16
			// 
			this.textBox16.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBox16.Font = new System.Drawing.Font("굴림", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.textBox16.Location = new System.Drawing.Point(319, 152);
			this.textBox16.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.textBox16.Multiline = true;
			this.textBox16.Name = "textBox16";
			this.textBox16.Size = new System.Drawing.Size(310, 71);
			this.textBox16.TabIndex = 5;
			// 
			// label20
			// 
			this.label20.AutoSize = true;
			this.label20.Dock = System.Windows.Forms.DockStyle.Fill;
			this.label20.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.label20.Location = new System.Drawing.Point(3, 225);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(310, 77);
			this.label20.TabIndex = 7;
			this.label20.Text = "주문내역검색";
			this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// textBox17
			// 
			this.textBox17.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBox17.Font = new System.Drawing.Font("굴림", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.textBox17.Location = new System.Drawing.Point(319, 229);
			this.textBox17.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.textBox17.Multiline = true;
			this.textBox17.Name = "textBox17";
			this.textBox17.Size = new System.Drawing.Size(310, 69);
			this.textBox17.TabIndex = 8;
			// 
			// groupBox10
			// 
			this.groupBox10.Controls.Add(this.tableLayoutPanel29);
			this.groupBox10.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox10.Location = new System.Drawing.Point(3, 330);
			this.groupBox10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.groupBox10.Name = "groupBox10";
			this.groupBox10.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.groupBox10.Size = new System.Drawing.Size(638, 324);
			this.groupBox10.TabIndex = 1;
			this.groupBox10.TabStop = false;
			this.groupBox10.Text = "검색";
			// 
			// tableLayoutPanel29
			// 
			this.tableLayoutPanel29.ColumnCount = 2;
			this.tableLayoutPanel29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 75F));
			this.tableLayoutPanel29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel29.Controls.Add(this.tableLayoutPanel27, 0, 0);
			this.tableLayoutPanel29.Controls.Add(this.tableLayoutPanel41, 1, 0);
			this.tableLayoutPanel29.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel29.Location = new System.Drawing.Point(3, 20);
			this.tableLayoutPanel29.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel29.Name = "tableLayoutPanel29";
			this.tableLayoutPanel29.RowCount = 1;
			this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 294F));
			this.tableLayoutPanel29.Size = new System.Drawing.Size(632, 302);
			this.tableLayoutPanel29.TabIndex = 0;
			// 
			// tableLayoutPanel27
			// 
			this.tableLayoutPanel27.ColumnCount = 3;
			this.tableLayoutPanel27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
			this.tableLayoutPanel27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
			this.tableLayoutPanel27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
			this.tableLayoutPanel27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 23F));
			this.tableLayoutPanel27.Controls.Add(this.button36, 0, 0);
			this.tableLayoutPanel27.Controls.Add(this.button37, 0, 1);
			this.tableLayoutPanel27.Controls.Add(this.button38, 0, 2);
			this.tableLayoutPanel27.Controls.Add(this.button39, 1, 0);
			this.tableLayoutPanel27.Controls.Add(this.button40, 1, 1);
			this.tableLayoutPanel27.Controls.Add(this.button48, 1, 2);
			this.tableLayoutPanel27.Controls.Add(this.button49, 2, 0);
			this.tableLayoutPanel27.Controls.Add(this.button50, 2, 1);
			this.tableLayoutPanel27.Controls.Add(this.button51, 2, 2);
			this.tableLayoutPanel27.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel27.Location = new System.Drawing.Point(3, 2);
			this.tableLayoutPanel27.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.tableLayoutPanel27.Name = "tableLayoutPanel27";
			this.tableLayoutPanel27.RowCount = 3;
			this.tableLayoutPanel27.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
			this.tableLayoutPanel27.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
			this.tableLayoutPanel27.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
			this.tableLayoutPanel27.Size = new System.Drawing.Size(468, 298);
			this.tableLayoutPanel27.TabIndex = 0;
			// 
			// button36
			// 
			this.button36.BackColor = System.Drawing.Color.White;
			this.button36.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button36.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button36.Location = new System.Drawing.Point(3, 4);
			this.button36.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button36.Name = "button36";
			this.button36.Size = new System.Drawing.Size(150, 91);
			this.button36.TabIndex = 0;
			this.button36.Text = "일매출";
			this.button36.UseVisualStyleBackColor = false;
			this.button36.Click += new System.EventHandler(this.button36_Click);
			// 
			// button37
			// 
			this.button37.BackColor = System.Drawing.Color.White;
			this.button37.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button37.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button37.Location = new System.Drawing.Point(3, 103);
			this.button37.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button37.Name = "button37";
			this.button37.Size = new System.Drawing.Size(150, 91);
			this.button37.TabIndex = 1;
			this.button37.Text = "일매출 합계";
			this.button37.UseVisualStyleBackColor = false;
			this.button37.Click += new System.EventHandler(this.button37_Click);
			// 
			// button38
			// 
			this.button38.BackColor = System.Drawing.Color.White;
			this.button38.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button38.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button38.Location = new System.Drawing.Point(3, 202);
			this.button38.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button38.Name = "button38";
			this.button38.Size = new System.Drawing.Size(150, 92);
			this.button38.TabIndex = 2;
			this.button38.Text = "일매출 평균";
			this.button38.UseVisualStyleBackColor = false;
			this.button38.Click += new System.EventHandler(this.button38_Click);
			// 
			// button39
			// 
			this.button39.BackColor = System.Drawing.Color.White;
			this.button39.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button39.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button39.Location = new System.Drawing.Point(159, 4);
			this.button39.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button39.Name = "button39";
			this.button39.Size = new System.Drawing.Size(150, 91);
			this.button39.TabIndex = 3;
			this.button39.Text = "월매출";
			this.button39.UseVisualStyleBackColor = false;
			this.button39.Click += new System.EventHandler(this.button39_Click);
			// 
			// button40
			// 
			this.button40.BackColor = System.Drawing.Color.White;
			this.button40.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button40.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button40.Location = new System.Drawing.Point(159, 103);
			this.button40.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button40.Name = "button40";
			this.button40.Size = new System.Drawing.Size(150, 91);
			this.button40.TabIndex = 4;
			this.button40.Text = "월매출 합계";
			this.button40.UseVisualStyleBackColor = false;
			this.button40.Click += new System.EventHandler(this.button40_Click);
			// 
			// button48
			// 
			this.button48.BackColor = System.Drawing.Color.White;
			this.button48.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button48.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button48.Location = new System.Drawing.Point(159, 202);
			this.button48.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button48.Name = "button48";
			this.button48.Size = new System.Drawing.Size(150, 92);
			this.button48.TabIndex = 5;
			this.button48.Text = "월매출 평균";
			this.button48.UseVisualStyleBackColor = false;
			this.button48.Click += new System.EventHandler(this.button48_Click);
			// 
			// button49
			// 
			this.button49.BackColor = System.Drawing.Color.White;
			this.button49.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button49.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button49.Location = new System.Drawing.Point(315, 4);
			this.button49.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button49.Name = "button49";
			this.button49.Size = new System.Drawing.Size(150, 91);
			this.button49.TabIndex = 6;
			this.button49.Text = "연매출";
			this.button49.UseVisualStyleBackColor = false;
			this.button49.Click += new System.EventHandler(this.button49_Click);
			// 
			// button50
			// 
			this.button50.BackColor = System.Drawing.Color.White;
			this.button50.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button50.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button50.Location = new System.Drawing.Point(315, 103);
			this.button50.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button50.Name = "button50";
			this.button50.Size = new System.Drawing.Size(150, 91);
			this.button50.TabIndex = 7;
			this.button50.Text = "연매출 합계";
			this.button50.UseVisualStyleBackColor = false;
			this.button50.Click += new System.EventHandler(this.button50_Click);
			// 
			// button51
			// 
			this.button51.BackColor = System.Drawing.Color.White;
			this.button51.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button51.Font = new System.Drawing.Font("굴림", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button51.Location = new System.Drawing.Point(315, 202);
			this.button51.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button51.Name = "button51";
			this.button51.Size = new System.Drawing.Size(150, 92);
			this.button51.TabIndex = 8;
			this.button51.Text = "연매출 평균";
			this.button51.UseVisualStyleBackColor = false;
			this.button51.Click += new System.EventHandler(this.button51_Click);
			// 
			// tableLayoutPanel41
			// 
			this.tableLayoutPanel41.ColumnCount = 1;
			this.tableLayoutPanel41.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel41.Controls.Add(this.button52, 0, 0);
			this.tableLayoutPanel41.Controls.Add(this.button53, 0, 1);
			this.tableLayoutPanel41.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel41.Location = new System.Drawing.Point(477, 4);
			this.tableLayoutPanel41.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel41.Name = "tableLayoutPanel41";
			this.tableLayoutPanel41.RowCount = 2;
			this.tableLayoutPanel41.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
			this.tableLayoutPanel41.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 66.66666F));
			this.tableLayoutPanel41.Size = new System.Drawing.Size(152, 294);
			this.tableLayoutPanel41.TabIndex = 1;
			this.tableLayoutPanel41.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel41_Paint);
			// 
			// button52
			// 
			this.button52.BackColor = System.Drawing.Color.White;
			this.button52.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button52.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button52.Location = new System.Drawing.Point(3, 4);
			this.button52.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button52.Name = "button52";
			this.button52.Size = new System.Drawing.Size(146, 90);
			this.button52.TabIndex = 0;
			this.button52.Text = "주문 내역별 검색";
			this.button52.UseVisualStyleBackColor = false;
			this.button52.Click += new System.EventHandler(this.button52_Click_1);
			// 
			// button53
			// 
			this.button53.BackColor = System.Drawing.Color.White;
			this.button53.Dock = System.Windows.Forms.DockStyle.Fill;
			this.button53.Font = new System.Drawing.Font("굴림", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.button53.Location = new System.Drawing.Point(3, 102);
			this.button53.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.button53.Name = "button53";
			this.button53.Size = new System.Drawing.Size(146, 188);
			this.button53.TabIndex = 1;
			this.button53.Text = "매출인쇄";
			this.button53.UseVisualStyleBackColor = false;
			this.button53.Click += new System.EventHandler(this.button53_Click);
			// 
			// tableLayoutPanel28
			// 
			this.tableLayoutPanel28.ColumnCount = 1;
			this.tableLayoutPanel28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel28.Controls.Add(this.dataGridView4, 0, 0);
			this.tableLayoutPanel28.Controls.Add(this.textBox19, 0, 1);
			this.tableLayoutPanel28.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel28.Location = new System.Drawing.Point(3, 4);
			this.tableLayoutPanel28.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.tableLayoutPanel28.Name = "tableLayoutPanel28";
			this.tableLayoutPanel28.RowCount = 2;
			this.tableLayoutPanel28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 85F));
			this.tableLayoutPanel28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
			this.tableLayoutPanel28.Size = new System.Drawing.Size(644, 652);
			this.tableLayoutPanel28.TabIndex = 2;
			// 
			// dataGridView4
			// 
			this.dataGridView4.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.dataGridView4.BackgroundColor = System.Drawing.Color.White;
			this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView4.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dataGridView4.Location = new System.Drawing.Point(3, 2);
			this.dataGridView4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.dataGridView4.Name = "dataGridView4";
			this.dataGridView4.RowTemplate.Height = 27;
			this.dataGridView4.Size = new System.Drawing.Size(638, 550);
			this.dataGridView4.TabIndex = 0;
			this.dataGridView4.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dataGridView4_RowPostPaint);
			// 
			// textBox19
			// 
			this.textBox19.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBox19.Font = new System.Drawing.Font("굴림", 33.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.textBox19.Location = new System.Drawing.Point(3, 558);
			this.textBox19.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.textBox19.Multiline = true;
			this.textBox19.Name = "textBox19";
			this.textBox19.Size = new System.Drawing.Size(638, 90);
			this.textBox19.TabIndex = 1;
			this.textBox19.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// timer1
			// 
			this.timer1.Enabled = true;
			this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
			// 
			// statusStrip1
			// 
			this.statusStrip1.AutoSize = false;
			this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
			this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripSplitButton1});
			this.statusStrip1.Location = new System.Drawing.Point(0, 697);
			this.statusStrip1.Name = "statusStrip1";
			this.statusStrip1.Padding = new System.Windows.Forms.Padding(16, 0, 1, 0);
			this.statusStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			this.statusStrip1.Size = new System.Drawing.Size(1314, 28);
			this.statusStrip1.TabIndex = 1;
			this.statusStrip1.Text = "statusStrip1";
			// 
			// toolStripStatusLabel1
			// 
			this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
			this.toolStripStatusLabel1.Size = new System.Drawing.Size(0, 0);
			this.toolStripStatusLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// toolStripSplitButton1
			// 
			this.toolStripSplitButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.toolStripSplitButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSplitButton1.Image")));
			this.toolStripSplitButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripSplitButton1.Name = "toolStripSplitButton1";
			this.toolStripSplitButton1.Size = new System.Drawing.Size(39, 26);
			this.toolStripSplitButton1.Text = "toolStripSplitButton1";
			this.toolStripSplitButton1.ButtonClick += new System.EventHandler(this.toolStripSplitButton1_ButtonClick);
			// 
			// timer2
			// 
			this.timer2.Enabled = true;
			this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
			// 
			// printDocument1
			// 
			this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
			// 
			// printDialog1
			// 
			this.printDialog1.UseEXDialog = true;
			// 
			// 포스
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1314, 725);
			this.Controls.Add(this.tableLayoutPanel1);
			this.Controls.Add(this.statusStrip1);
			this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.Name = "포스";
			this.Text = "포스";
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			this.Load += new System.EventHandler(this.Form1_Load);
			this.tableLayoutPanel1.ResumeLayout(false);
			this.tabControl1.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			this.tableLayoutPanel2.ResumeLayout(false);
			this.tableLayoutPanel4.ResumeLayout(false);
			this.tableLayoutPanel5.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
			this.groupBox1.ResumeLayout(false);
			this.tableLayoutPanel6.ResumeLayout(false);
			this.tableLayoutPanel6.PerformLayout();
			this.tableLayoutPanel7.ResumeLayout(false);
			this.groupBox4.ResumeLayout(false);
			this.tableLayoutPanel8.ResumeLayout(false);
			this.tableLayoutPanel30.ResumeLayout(false);
			this.tableLayoutPanel31.ResumeLayout(false);
			this.groupBox3.ResumeLayout(false);
			this.tableLayoutPanel9.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.tableLayoutPanel10.ResumeLayout(false);
			this.tableLayoutPanel3.ResumeLayout(false);
			this.tableLayoutPanel3.PerformLayout();
			this.tabPage2.ResumeLayout(false);
			this.tableLayoutPanel11.ResumeLayout(false);
			this.tableLayoutPanel14.ResumeLayout(false);
			this.groupBox6.ResumeLayout(false);
			this.tableLayoutPanel15.ResumeLayout(false);
			this.groupBox5.ResumeLayout(false);
			this.tableLayoutPanel16.ResumeLayout(false);
			this.tableLayoutPanel16.PerformLayout();
			this.tableLayoutPanel12.ResumeLayout(false);
			this.tableLayoutPanel13.ResumeLayout(false);
			this.tableLayoutPanel32.ResumeLayout(false);
			this.tableLayoutPanel33.ResumeLayout(false);
			this.tableLayoutPanel34.ResumeLayout(false);
			this.tableLayoutPanel35.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
			this.tableLayoutPanel42.ResumeLayout(false);
			this.groupBox12.ResumeLayout(false);
			this.groupBox12.PerformLayout();
			this.tabPage3.ResumeLayout(false);
			this.tableLayoutPanel17.ResumeLayout(false);
			this.tableLayoutPanel18.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
			this.tableLayoutPanel19.ResumeLayout(false);
			this.groupBox7.ResumeLayout(false);
			this.tableLayoutPanel20.ResumeLayout(false);
			this.tableLayoutPanel20.PerformLayout();
			this.groupBox8.ResumeLayout(false);
			this.tableLayoutPanel21.ResumeLayout(false);
			this.tableLayoutPanel21.PerformLayout();
			this.tableLayoutPanel36.ResumeLayout(false);
			this.tableLayoutPanel36.PerformLayout();
			this.groupBox11.ResumeLayout(false);
			this.tableLayoutPanel40.ResumeLayout(false);
			this.tableLayoutPanel40.PerformLayout();
			this.tableLayoutPanel37.ResumeLayout(false);
			this.tableLayoutPanel37.PerformLayout();
			this.tableLayoutPanel38.ResumeLayout(false);
			this.tableLayoutPanel38.PerformLayout();
			this.tableLayoutPanel39.ResumeLayout(false);
			this.tableLayoutPanel39.PerformLayout();
			this.tableLayoutPanel22.ResumeLayout(false);
			this.tableLayoutPanel23.ResumeLayout(false);
			this.tabPage4.ResumeLayout(false);
			this.tableLayoutPanel24.ResumeLayout(false);
			this.tableLayoutPanel25.ResumeLayout(false);
			this.groupBox9.ResumeLayout(false);
			this.tableLayoutPanel26.ResumeLayout(false);
			this.tableLayoutPanel26.PerformLayout();
			this.groupBox10.ResumeLayout(false);
			this.tableLayoutPanel29.ResumeLayout(false);
			this.tableLayoutPanel27.ResumeLayout(false);
			this.tableLayoutPanel41.ResumeLayout(false);
			this.tableLayoutPanel28.ResumeLayout(false);
			this.tableLayoutPanel28.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
			this.statusStrip1.ResumeLayout(false);
			this.statusStrip1.PerformLayout();
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel14;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel15;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel16;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel17;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel18;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel19;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel20;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel21;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel22;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel23;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel24;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel25;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel26;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel27;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel30;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel31;
        private System.Windows.Forms.Button button21;
        public System.Windows.Forms.DataGridView dataGridView1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintDialog printDialog1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel36;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel40;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel37;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel38;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel39;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel28;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel29;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel41;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.TextBox textBox17;
        public System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButton1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel12;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel13;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel32;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel33;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel34;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel35;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel42;
        private System.Windows.Forms.Button button54;
        public System.Windows.Forms.DataGridView dataGridView3;
    }
}

