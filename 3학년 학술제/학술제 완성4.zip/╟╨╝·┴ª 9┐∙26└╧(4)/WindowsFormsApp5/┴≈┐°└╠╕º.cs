﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp5
{
    class 직원이름
    {
        public string 메뉴
        {
            get;
            set;
        }

        public 직원이름(string item)
        {
            메뉴 = item;
        }
    }
}
